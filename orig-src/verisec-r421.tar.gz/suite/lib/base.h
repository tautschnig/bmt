#ifndef _BASE_H
#define _BASE_H

/* Only #define it if it hasn't already been defined using -D */
#ifndef BASE_SZ
#define BASE_SZ 2
#endif

#ifndef MAX_GETC
#define MAX_GETC 10
#endif

#endif
