#include "../../../../lib/stubs.h"

#define BUFSZ BASE_SZ + 2
#define INSZ BUFSZ + 5

