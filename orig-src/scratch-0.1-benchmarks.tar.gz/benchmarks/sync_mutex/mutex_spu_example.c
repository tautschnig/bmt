/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <stdio.h>
#include <spu_mfcio.h>
#ifdef NO_SLICE
#include <libsync.h>
#endif
#include "mutex_example.h"

static mutex_spu_test_argv_t spu_argv __attribute__ ((aligned (128)));
static volatile int lsbuf[BUFFER_SIZE] __attribute__ ((aligned (128)));

int spu_main (unsigned long long spuid __attribute__ ((unused)), 
          unsigned long long argp)
{ 
  int i;
  unsigned int tag_id;
  mutex_ea_t mutex;
  int j ;

  PRINTF ("SPU main begins argp = 0x%llx\n", argp);

  /* reserve a tag id */
  tag_id = mfc_tag_reserve() & 31;

  /* dma_get to get the content of argv */
  mfc_write_tag_mask (1 << tag_id);
  mfc_get ((void*)&spu_argv, argp, sizeof(mutex_spu_test_argv_t), tag_id, 0, 0);
  mfc_read_tag_status_all();
  
  PRINTF ("SPU main, argv.buf_ea = %lli\n", spu_argv.buf_ea); 
  mutex = spu_argv.mutex_ea;
  for (i = 0; i < LOOP_COUNT; i++) {
    mutex_lock (mutex);
    PRINTF ("SPU main, finished calling mutex_lock i = %d\n", i);

    if (mutex_trylock(mutex)) {
      printf("SPU incorrectly got the lock a second time - exiting!\n");
#ifdef NO_SLICE
      mutex_unlock (mutex);
      break;
#endif
    } else {
      PRINTF("SPU did not get lock a second time.\n");
    }

    mfc_write_tag_mask (1 << (tag_id
#ifndef CORRECT
    /* BUG - tag value is out by one.  This means that wait will not refer to correct tag */							  
						+ 1
#endif	  
	  ));
    mfc_get ((void*)lsbuf, (unsigned int)spu_argv.buf_ea, sizeof(int)*BUFFER_SIZE, tag_id, 0, 0);
    mfc_read_tag_status_all();

#ifdef NO_SLICE	  
    for (j = 0; j < BUFFER_SIZE; j++) {
      lsbuf[j] += 1;
	}
#endif
	  
    mfc_write_tag_mask (1 << tag_id);
    mfc_put ((void*)lsbuf, (unsigned int)spu_argv.buf_ea, sizeof(int)*BUFFER_SIZE, tag_id, 0, 0);
    mfc_read_tag_status_all();
    
    mutex_unlock (mutex);
    PRINTF ("SPU main, finished calling mutex_unlock i = %d\n", i);
    
  }
  PRINTF ("SPU main ends\n");

  return 0; 
}
