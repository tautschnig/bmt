/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include "particle.h"

#define PARTICLES_PER_BLOCK		1024	/* # of particles to process at a time */

#ifdef NO_SLICE

typedef vector float float4;

#else

typedef struct float4_s {
  float data[4];
} float4;

#endif

// Local store structures and buffers.
volatile parm_context ctx;
volatile float4 pos[PARTICLES_PER_BLOCK] __attribute__ ((aligned (128)));
volatile float4 vel[PARTICLES_PER_BLOCK] __attribute__ ((aligned (128)));
volatile float inv_mass[PARTICLES_PER_BLOCK] __attribute__ ((aligned (128)));

int spu_main(unsigned long long spu_id __attribute__ ((unused)), unsigned long long parm)
{
  int i, j;
  int left, cnt;
  float time;
  unsigned int tag_id;
  float4 dt_v, dt_inv_mass_v;

  // Reserve a tag ID
  tag_id = mfc_tag_reserve();

  mfc_write_tag_mask(-1);

  // Input parameter parm is a pointer to the particle parameter context.
  // Fetch the context, waiting for it to complete.
  
  mfc_get((void *)(&ctx), (unsigned int)parm, sizeof(parm_context), tag_id, 0, 0);
  HAVOC_CONTEXT(ctx);

  mfc_read_tag_status_all();

  //  dt_v = spu_splats(ctx.dt);

  // For each step in time
  time = 0;

#define OUTER_PREFIX 0
#define INNER_BODY 1
#define OUTER_POSTFIX 2

  int state = OUTER_PREFIX;


  while(time < END_OF_TIME) {

    if(state == OUTER_PREFIX) {
      i = 0;
      state = INNER_BODY;
    }

    if(state == INNER_BODY) {

      if(i<ctx.particles) {
	// Determine the number of particles in this block.
	left = ctx.particles - i;
	cnt = (left < PARTICLES_PER_BLOCK) ? left : PARTICLES_PER_BLOCK;
	
	// Fetch the data - position, velocity and inverse_mass. Wait for the DMA to complete 
	// before performing computation.
#ifdef CORRECT
	mfc_getb
#else
        /* BUG - get with barrier replaced by standard get - this causes a DMA race */
	mfc_get
#endif
	((void *)(pos), (unsigned int)(ctx.pos_v+i), cnt * sizeof(float4), tag_id, 0, 0);
	mfc_get((void *)(vel), (unsigned int)(ctx.vel_v+i), cnt * sizeof(float4), tag_id, 0, 0);
	mfc_get((void *)(inv_mass), (unsigned int)(ctx.inv_mass+i), cnt * sizeof(float), tag_id, 0, 0);
	mfc_read_tag_status_all();
	
	// Compute the step in time for the block of particles

#ifdef NO_SLICE
	for (j=0; j<cnt; j++) {
	  pos[j] = spu_madd(vel[j], dt_v, pos[j]);
	  dt_inv_mass_v = spu_mul(dt_v, spu_splats(inv_mass[j]));
	  vel[j] = spu_madd(dt_inv_mass_v, ctx.force_v, vel[j]);
	}
#endif
	
	// Put the position and velocity data back into system memory
	mfc_put((void *)(pos), (unsigned int)(ctx.pos_v+i), cnt * sizeof(float4), tag_id, 0, 0);
	mfc_put((void *)(vel), (unsigned int)(ctx.vel_v+i), cnt * sizeof(float4), tag_id, 0, 0);
	
	i+=PARTICLES_PER_BLOCK;

      } else {
	state = OUTER_POSTFIX;
      }

    }

    if(state == OUTER_POSTFIX) {
      time += ctx.dt;
      state = OUTER_PREFIX;
    }

  }
  // Wait for final DMAs to complete before terminating SPU thread.
  mfc_read_tag_status_all();
  return (0);
}
