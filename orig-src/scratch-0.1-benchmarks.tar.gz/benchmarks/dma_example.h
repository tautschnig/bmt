/*---------------------------------------------------------------------*/
/* Definitions to allow different tag reserve strategies to be applied */
/*---------------------------------------------------------------------*/

#ifdef USE_TAG_RESERVE

/* Actually use the tag reserve function */

#define TAG_RESERVE(x) mfc_tag_reserve()
#define TAG_ASSERT(t, x) assert( ( (t) >= 0 ) && ( (t) < 32 ) )

#else

/* Set tag to a given value */

#define TAG_RESERVE(x) x
#define TAG_ASSERT(t, x) assert( (t) == x )

#endif



/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#ifndef _dma_example_h_
#define _dma_example_h_

#define MAX_NUM_SPE_THREADS     1                                         //Number of SPEs to be used
#define ARRAY_SIZE              (1024 * 1024 * MAX_NUM_SPE_THREADS)         //Total array size


/* Here we define a control block data structure that contains 
 * all the data the SPE needed to get the large array of data into
 * local store.
 *
 * This data structure has a size that's a multiple of 16 bytes */
typedef struct _control_block
{
  unsigned long long in_addr;   //beginning address of the input array
  unsigned long long out_addr;  //beginning address of the output array
  unsigned int       num_elements_per_spe; //number of elements assigned to this spe for processing
  unsigned int       id;        //spe id
  unsigned int       pad[2];
} control_block_t;


#define HAVOC_CONTROL_BLOCK(c) \
    c.in_addr = __CPROVER_ndet_int(); \
    c.out_addr = __CPROVER_ndet_int(); \
    c.num_elements_per_spe = __CPROVER_ndet_int(); \
    c.id = __CPROVER_ndet_int(); \
    c.pad[0] = __CPROVER_ndet_int(); \
    c.pad[1] = __CPROVER_ndet_int()

#endif /* _dma_example_h_ */
