%% --------------------------------------------------------------  
%% (C)Copyright 2001,2007,                                         
%% International Business Machines Corporation,                    
%% Sony Computer Entertainment, Incorporated,                      
%% Toshiba Corporation,                                            
%%                                                                 
%% All Rights Reserved.                                            
%%                                                                 
%% Redistribution and use in source and binary forms, with or      
%% without modification, are permitted provided that the           
%% following conditions are met:                                   
%%                                                                 
%% - Redistributions of source code must retain the above copyright
%%   notice, this list of conditions and the following disclaimer. 
%%                                                                 
%% - Redistributions in binary form must reproduce the above       
%%   copyright notice, this list of conditions and the following   
%%   disclaimer in the documentation and/or other materials        
%%   provided with the distribution.                               
%%                                                                 
%% - Neither the name of IBM Corporation nor the names of its      
%%   contributors may be used to endorse or promote products       
%%   derived from this software without specific prior written     
%%   permission.                                                   
%%                                                                 
%% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          
%% CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     
%% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        
%% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        
%% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            
%% CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    
%% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    
%% NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    
%% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        
%% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       
%% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    
%% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  
%% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              
%% --------------------------------------------------------------  
%% PROLOG END TAG zYx                                              
Atomic operations example

This example program shows how the atomic operations provided
with this SDK work. 

The syntax is: atomic_op_example <Number_of_SPEs>

  The optional argument sets the numbert of SPEs used in the testing,
which can range from 2 to 16 and defaults to the number of usable SPEs.

  There is a test for each atomic operation (except atomic_read, which
is called by several of the other tests).  In each case the PPE creates 
an atomic variable and starts the set number of SPEs. Then all SPEs and 
the PPE simultaneously update that variable (using a loop size of LOOP_COUNT)
and when all are completed, the PPE checks the value to confirm it's set 
to what is expected.

do_atomic_add_spu_test
  Starting at 0, add 1 at each loop.  This only includes SPEs.

do_atomic_add_cbe_test
  Starting at 0, add 1 at each loop.  This includes both SPEs and PPE.

do_atomic_add_return_test 
  Starting at 0, add 1 at each loop.  Use the returns from atomic_add_return
and atomic_read to confirm they are giving the correct output at the end of
each loop.

do_atomic_set_test
  Each loop sets the atomic to the loop counter, so it should end up
set as LOOP_COUNT - 1.

do_atomic_inc_test 
  Starting at 0, increment (by 1) at each loop.

do_atomic_inc_return_test 
  Starting at 0, increment (by 1) at each loop. Use the returns from 
atomic_inc_return and atomic_read to confirm they are giving the correct 
output at the end of each loop.

do_atomic_sub_spu_test
  Starting at (num_spus * LOOP_COUNT), subtract 1 at each loop.  
This only includes SPEs.

do_atomic_sub_cbe_test
  Starting at ((num_spus+1) * LOOP_COUNT), subtract 1 at each loop.
This only includes both SPEs and the PPE.

do_atomic_sub_return_test
  Starting at ((num_spus+1) * LOOP_COUNT), subtract 1 at each loop.
Use the returns from atomic_sub_return and atomic_read to confirm 
they are giving the correct output at the end of each loop.

do_atomic_sub_and_test_test
  Starting at ((num_spus+1) * LOOP_COUNT), subtract 1 at each loop.
Use the return from atomic_sub_and_test to confirm it properly returns
1 only when the atomic is set to 0.

do_atomic_dec_test 
  Starting at ((num_spus+1) * LOOP_COUNT), decrement (by 1) at each loop.

do_atomic_dec_return_test 
  Starting at ((num_spus+1) * LOOP_COUNT), decrement (by 1) at each loop.
Use the returns from atomic_dec_return and atomic_read to confirm they 
are giving the correct output at the end of each loop.

do_atomic_dec_and_test_test 
  Starting at ((num_spus+1) * LOOP_COUNT), decrement (by 1) at each loop.
Use the return from atomic_dec_and_test to confirm it properly returns
1 only when the atomic is set to 0.

do_atomic_dec_if_positive_test
  Starting at ((num_spus-1) * LOOP_COUNT-1), decrement (by 1) at each loop.
Confirm that at the end, even though it should have decremented below 0,
the value is still 0.

