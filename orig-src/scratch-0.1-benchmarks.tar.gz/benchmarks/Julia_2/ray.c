/* --------------------------------------------------------------  */
/* Copyright (c) 1984-2005, Keenan Crane                           */
/* All rights reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the following */
/* conditions are met:                                             */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials provided */
/* with the distribution.                                          */
/*                                                                 */
/* The name of Keenan Crane may not be used to endorse or promote  */
/* products derived from this software without specific prior      */
/* written permission.                                             */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/* frag.c - SPU-C fractal raytracer, ported from 
 *
 * 	QJuliaFragment.cg 
 *	Keenan Crane (kcrane@uiuc.edu)
 */

#ifdef USE_TAG_RESERVE

/* Actually use the tag reserve function */

#define TAG_RESERVE(x) mfc_tag_reserve()
#define TAG_ASSERT(t, x) assert( ( (t) >= 0 ) && ( (t) < 32 ) )
#define MASK_ASSERT(m, x)
#else

/* Set tag to a given value */

#define TAG_RESERVE(x) x
#define TAG_ASSERT(t, x) assert( (t) == x )
#define MASK_ASSERT(m, x) assert( (m) == (x) )

#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#ifdef NO_SLICE
#include <simdmath/recipf4.h>
#include <simdmath/fabsf4.h>
#include <simdmath/powf4.h>
#include <simdmath/sqrtf4.h>
#include <simdmath/logf4.h>
#include <cross_product3.h>
#include <dot_product3.h>
#include <dot_product4.h>
#include <mult_quat.h>
#include <normalize3.h>
#include <sum_across_float4.h>
#endif

#include <spu_mfcio.h>

#ifdef NO_SLICE
#include <mfc.h>
#endif

#include "../julia.h"

#define BOUNDING_RADIUS_2	3.0f
#define ESCAPE_THRESHOLD	1e1f
#define DEL			1e-4f

#define FMINF_V(_a, _b)		spu_sel(_a, _b, spu_cmpgt(_a, _b))
#define FMAXF_V(_a, _b)		spu_sel(_a, _b, spu_cmpgt(_b, _a))

typedef union
{
  unsigned long long ull;
  void *vp[2];
}
addr64;

#define dot3(a, b)		_dot_product3(a, b)
#define dot4(a, b)		_dot_product4(a, b)
#define cross(a, b)		_cross_product3(a, b)

#ifdef NO_SLICE
typedef vector float float4;
#else
typedef struct float4_s
{
  float data[4];
} float4;
#endif

volatile signed int mywriteback[4] __attribute__ ((aligned (128))) =
{
BUFFER_READY, BUFFER_READY, BUFFER_READY, BUFFER_READY};

volatile rendering_context rc __attribute__ ((aligned (128)));
volatile rendering_region region __attribute__ ((aligned (128)));
volatile float4 image_buf[2][MAX_IMG_HEIGHT]
  __attribute__ ((aligned (128)));


#ifdef NO_SLICE

static inline float
length (vector float v)
{
  return spu_extract(_sqrtf4 (spu_promote(_sum_across_float4 (spu_mul (v, v)), 0)), 0);
}


static inline vector float
quatMult (vector float q1, vector float q2)
{
  float q1_x = spu_extract (q1, 0);
  float q2_x = spu_extract (q2, 0);
  vector float q1_yzw = spu_slqwbyte (q1, 4);
  vector float q2_yzw = spu_slqwbyte (q2, 4);
  float rx = q1_x * q2_x - dot3 (q1_yzw, q2_yzw);
  vector float ryzw = spu_madd (spu_splats (q1_x), q2_yzw,
				spu_madd (spu_splats (q2_x), q1_yzw,
					  cross (q1_yzw, q2_yzw)));
  return spu_insert (rx, spu_rlmaskqwbyte (ryzw, -4), 0);
}


static inline vector float
quatSq (vector float q)
{
  vector float result;
  float q_x = spu_extract (q, 0);
  vector float q_yzw = spu_slqwbyte (q, 4);
  float rx = q_x * q_x - dot3 (q_yzw, q_yzw);
  vector float ryzw = spu_mul (spu_splats (2.0f * q_x), q_yzw);
  result = spu_insert (rx, spu_rlmaskqwbyte (ryzw, -4), 0);
  return result;
}


static inline void
IterateIntersect (vector float *_q, vector float *_qp, vector float c,
		  int maxIterations)
{
  vector float q = *_q;
  vector float qp = *_qp;
  int i;

  for (i = 0; i < maxIterations; i++)
    {
      qp = spu_mul (spu_splats(2.0f), quatMult (q, qp));
      q = spu_add (quatSq (q), c);
      if (dot4 (q, q) > ESCAPE_THRESHOLD)
	{
	  break;
	}
    }
  *_qp = qp;
  *_q = q;
}


static inline vector float
normEstimate (vector float p, vector float c, int maxIterations)
{
  vector float N = spu_splats(0.0f);
  vector float qP = spu_insert (0.0f, p, 3);
  vector float I = ( (vector float) { DEL, 0.0f, 0.0f, 0.0f});
  vector float J = ( (vector float) { 0.0f, DEL, 0.0f, 0.0f});
  vector float K = ( (vector float) { 0.0f, 0.0f, DEL, 0.0f});
  vector float gx1 = spu_sub (qP, I);
  vector float gx2 = spu_add (qP, I);
  vector float gy1 = spu_sub (qP, J);
  vector float gy2 = spu_add (qP, J);
  vector float gz1 = spu_sub (qP, K);
  vector float gz2 = spu_add (qP, K);
  int i;

  for (i = 0; i < maxIterations; i++)
    {
      gx1 = spu_add (quatSq (gx1), c);
      gx2 = spu_add (quatSq (gx2), c);
      gy1 = spu_add (quatSq (gy1), c);
      gy2 = spu_add (quatSq (gy2), c);
      gz1 = spu_add (quatSq (gz1), c);
      gz2 = spu_add (quatSq (gz2), c);
    }

  N = spu_insert (length (gx2) - length (gx1), N, 0);
  N = spu_insert (length (gy2) - length (gy1), N, 1);
  N = spu_insert (length (gz2) - length (gz1), N, 2);
  return _normalize3 (N);
}


static inline float
intersectQJulia (vector float *_rO, vector float rD, vector float c,
		 int maxIterations, float epsilon)
{
  vector float rO = *_rO;
  float dist;
  float maxstep = 0.3f;

  while (1)
    {
      vector float z = spu_insert (0.0f, rO, 3);
      vector float zp = ( (vector float) { 1.0f, 0.0f, 0.0f, 0.0f});
      float normZ;

      IterateIntersect (&z, &zp, c, maxIterations);

      normZ = length (z);
      dist = 0.5f * normZ * spu_extract(_logf4 (spu_promote(normZ, 0)), 0) / length (zp);
      dist = spu_extract(FMINF_V(spu_promote(dist, 0), spu_promote(maxstep, 0)), 0);
      rO = spu_madd (rD, spu_splats (dist), rO);

      if (dist < epsilon || dot3 (rO, rO) > BOUNDING_RADIUS_2)
	break;
    }
  *_rO = rO;
  return dist;
}


static inline vector float
Phong (vector float light, vector float eye, vector float pt, vector float N)
{
  const vector float diffuse =
    ( (vector float) { 1.0f, 0.45f, 0.25f, 0.0f});
  const float specExp = 10.0f;
  const float specularity = 0.45f;
  const vector float L = _normalize3 (spu_sub (light, pt));
  const vector float E = _normalize3 (spu_sub (eye, pt));
  const float NdotL = dot3 (N, L);
  const vector float R = spu_sub (spu_mul (spu_splats (2.0f * NdotL), N), L);
  const vector float diff =
    spu_madd (_fabsf4 (N), spu_splats (0.3f), diffuse);
  const float spec =
    specularity * spu_extract(_powf4 (FMAXF_V (spu_promote(dot3 (E, R), 0),
					       spu_splats(0.0f)), 
				      spu_promote(specExp, 0)), 0);
  return spu_madd (diff, FMAXF_V (spu_splats(NdotL), spu_splats(0.0f)),
		   spu_splats (spec));
}


static inline vector float
intersectSphere (vector float rO, vector float rD)
{
  float B, C, d, t0, t1, t;

  B = 2.0f * dot3 (rO, rD);
  C = dot3 (rO, rO) - BOUNDING_RADIUS_2;
  d = spu_extract(_sqrtf4(spu_promote((B * B - 4.0f * C), 0)), 0);
  t0 = (-B + d) * 0.5f;
  t1 = (-B - d) * 0.5f;
  t = spu_extract(FMINF_V (spu_promote(t0, 0), spu_promote(t1, 0)), 0);
  return spu_madd (spu_splats (t), rD, rO);
}


static inline vector float
FragmentShader (vector float rO, vector float rD, vector float mu,
		float epsilon, vector float light, int renderShadows,
		int maxIterations)
{
  const vector float bg_color =
    ( (vector float) { 0.3, 0.3, 0.3, 1.0});
  vector float color = bg_color;
  vector float eye = rO;
  float dist;

  rD = _normalize3 (rD);
  rO = intersectSphere (rO, rD);
  dist = intersectQJulia (&rO, rD, mu, maxIterations, epsilon);

  if (dist < epsilon)
    {
      vector float N = normEstimate (rO, mu, maxIterations);

      color = Phong (light, eye, rO, N);
      color = spu_insert (1.0f, color, 3);

      if (renderShadows)
	{
	  vector float L = _normalize3 (spu_sub (light, rO));

	  rO = spu_madd (N, spu_splats (epsilon * 2.0f), rO);
	  dist = intersectQJulia (&rO, L, mu, maxIterations, epsilon);

	  if (dist < epsilon)
	    {
	      const vector float shade =
		( (vector float) { 0.4f, 0.4f, 0.4f, 1.0f});
	      color = spu_mul (color, shade);
	    }
	}
    }
  return color;
}

#endif


int
spu_main()
{
  unsigned int i, j;
  unsigned int ea_low;
  unsigned int opcode;
  unsigned int now_tag;
  unsigned int now_mask;
  unsigned int sc_tag[2];
  unsigned int sc_mask[2];

  unsigned int wb_addr = (unsigned int)NULL;
#ifdef NO_SLICE
  vector float rO = spu_splats(0.0f);
  vector float mu = spu_splats(0.0f);
  vector float eye = spu_splats(0.0f);
  vector float light = spu_splats(0.0f);
#endif
  float epsilon = 0;
  int renderShadows = 0;
  int maxIterations = 0;
#ifdef NO_SLICE
  vector float r_top_start;
  vector float r_bottom_start;
  vector float r_bottom_stop;
  vector float dir_top;
  vector float dir_bottom;
  vector float curr_dir;
  vector float curr_dir2;
#endif
  int curr_buf = 0;
  unsigned int fb_ea_low;
  unsigned int fb_row_stride;
  unsigned int fb_store;
  unsigned int num_columns;
  unsigned int start_column;
  unsigned int num_rows;
  float imgWidth = 0, imgHeight = 0;
#ifdef NO_SLICE
  vector float px, py;
  vector float py2;
  vector float inv_width, inv_height;
  vector float ddx, ddy;
#endif
  int state;

#define OUTER_PREFIX 0
#define INNER_BODY 1

  // Reserve the tag ids used by this demo

  now_tag = TAG_RESERVE(0);
  sc_tag[0] = TAG_RESERVE(1);
  sc_tag[1] = TAG_RESERVE(2);

  assert((now_tag != MFC_TAG_INVALID) && 
	 (sc_tag[0] != MFC_TAG_INVALID) && 
	 (sc_tag[1] != MFC_TAG_INVALID)); 

  now_mask = 1 << now_tag;
  sc_mask[0] = 1 << sc_tag[0];
  sc_mask[1] = 1 << sc_tag[1];

  opcode = (unsigned int) spu_read_in_mbox();

  __CPROVER_assume(opcode == RENDER_CONTEXT_SPE_OP);

  ea_low = (unsigned int) spu_read_in_mbox ();

  mfc_get ((void *) &rc, ea_low,
	   sizeof (rendering_context), now_tag, 0, 0);
  HAVOC_RENDERING_CONTEXT(rc);
  mfc_write_tag_mask (now_mask);
  mfc_read_tag_status_all ();
  #ifdef NO_SLICE
  rO = *((vector float *) rc.eyeP);
  eye = *((vector float *) rc.eyeP);
  light = *((vector float *) rc.lightP);
  #endif
  epsilon = rc.epsilonP;
  renderShadows = rc.shadowsP;
  maxIterations = rc.iterationsP;
  wb_addr = (unsigned int) rc.wb_addr;
  imgWidth = (float) rc.img_width;
  imgHeight = (float) rc.img_height;

  state = OUTER_PREFIX;

  int finished = 0;

  while(!finished)
    {
      TAG_ASSERT(now_tag, 0);
      TAG_ASSERT(sc_tag[0], 1);
      TAG_ASSERT(sc_tag[1], 2);
      MASK_ASSERT(now_mask, (1 << now_tag) );
      MASK_ASSERT(sc_mask[0], (1 << sc_tag[0]));
      MASK_ASSERT(sc_mask[1], (1 << sc_tag[1]));

      assert((curr_buf == 0) || (curr_buf == 1));

      if(state == OUTER_PREFIX)
	{
	  opcode = (unsigned int) spu_read_in_mbox ();
      	  __CPROVER_assume(opcode == RAY_REGION_SPE_OP);
      
	  ea_low = (unsigned int) spu_read_in_mbox ();
	  mfc_get ((void *) &region, ea_low,
		     sizeof (rendering_region), now_tag, 0, 0);
	  HAVOC_RENDERING_REGION(region);
	  mfc_write_tag_mask (now_mask);
	  mfc_read_tag_status_all ();
#ifdef NO_SLICE
	  mu = *((vector float *) region.muP);
	  r_top_start = *((vector float *) region.dir_top_start);
	  r_bottom_start = *((vector float *) region.dir_bottom_start);
	  r_bottom_stop = *((vector float *) region.dir_bottom_stop);
#endif
	  fb_ea_low = region.fb_start;
	  fb_row_stride = MAX_IMG_HEIGHT * sizeof (float4);
	  num_rows = imgHeight;
	  num_columns = region.column_count;

	  __CPROVER_assume((num_columns>0) && (num_columns<=(FIXED_NUM_COLUMNS)));
	  start_column = region.column_start;
	  
	  fb_store = fb_ea_low + (start_column * fb_row_stride);

#ifdef NO_SLICE	  
	  dir_top = r_top_start;
	  dir_bottom = r_bottom_start;
	  
	  inv_width = _recipf4 (spu_splats (imgWidth));
	  inv_height = _recipf4 (spu_splats (imgHeight));
	  
	  ddx = spu_sub (r_bottom_stop, r_bottom_start);
	  ddy = spu_sub (r_top_start, r_bottom_start);
	  
	  ddx = spu_mul (ddx, inv_width);
	  ddy = spu_mul (ddy, inv_height);
	  
	  px = spu_splats ((float) start_column);
#endif
	  
	  i = 0;

	  state = INNER_BODY;

	}

      if(state == INNER_BODY)
	{
	  assert((num_columns>0) && (num_columns<=(FIXED_NUM_COLUMNS)));
	  if(!(i<num_columns))
	    {
	      state = OUTER_PREFIX;
	    }
	  else
	    {
#ifdef NO_SLICE
	      py = spu_splats(0.0f);
	      py2 = spu_splats(1.0f);
#endif
	      mfc_write_tag_mask (sc_mask[curr_buf]);
#ifdef CORRECT
	      mfc_read_tag_status_all ();
#else
	      /* BUG - omitted wait */
#endif

#ifdef NO_SLICE
	      for (j = 0; j < num_rows; j += 2)
		{
		  curr_dir = spu_madd (px, ddx, r_bottom_start);
		  curr_dir2 = spu_madd (px, ddx, r_bottom_start);
		  curr_dir = spu_madd (py, ddy, curr_dir);
		  curr_dir2 = spu_madd (py2, ddy, curr_dir2);
		  image_buf[curr_buf][j] =
		    FragmentShader (rO, curr_dir, mu, epsilon, light,
				    renderShadows, maxIterations);
		  image_buf[curr_buf][j + 1] =
		    FragmentShader (rO, curr_dir2, mu, epsilon, light,
				    renderShadows, maxIterations);
		  py = spu_add (py, spu_splats(2.0f));
		  py2 = spu_add (py2, spu_splats(2.0f));
		}
#endif
	      mfc_put (image_buf[curr_buf], fb_store,
	      		 fb_row_stride, sc_tag[curr_buf], 0, 0);
	      curr_buf = 1 - curr_buf;
#ifdef NO_SLICE
	      px = spu_add (px, spu_splats(1.0f));
#endif
	      fb_store += fb_row_stride;
	      
	      i++;
	    }
	}
    }
}
