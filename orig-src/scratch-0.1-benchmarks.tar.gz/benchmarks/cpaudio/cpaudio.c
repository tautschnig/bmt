/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2007,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * cpaudio.c
 *
 * Stand-alone 'spulet' that copies one channel of a stereo
 * audio file to the other channel.
 * The file contents are mmap'd into the effective address
 * space and double-buffered DMAs are used to stage data 
 * into and then out from LS.
 * 
 * This example illustrates how a SPE-based audio filter 
 * might be constructed. This type of filter might be combined with
 * other filters in a pipeline fashion to apply multiple filters to
 * the same file.
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spu_mfcio.h>
#include <spu_intrinsics.h>
#include <assert.h>



#ifdef USE_TAG_RESERVE

/* Actually use the tag reserve function */

#define MULTI_TAG_RESERVE(x, num) mfc_tag_reserve(num)
#define TAG_ASSERT(t, x) assert( ( (t) >= 0 ) && ( (t) < 32 ) )

#else

/* Set tag to a given value */

#define MULTI_TAG_RESERVE(x, num) x
#define TAG_ASSERT(t, x) assert( (t) == x )

#endif


#define BUF_SIZE_SHIFT 10
#define BUF_SIZE      (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_MASK (BUF_SIZE - 1)


#ifdef NO_SLICE

typedef vector unsigned short ushort8;

#else

typedef struct ushort8_s {
  unsigned short data[8];
} ushort8;

#endif

ushort8 in[2][BUF_SIZE];
ushort8 out[2][BUF_SIZE];


#ifdef NO_SLICE
static void channel_copy(ushort8 in[], 
                         ushort8 out[],
                         int length,
                         ushort8 mask,
                         int rotate_bytes) {
    int i;
    ushort8 in0, in1, in2, in3, in4, in5, in6, in7,
                          in0s, in1s, in2s, in3s, in4s, in5s, in6s, in7s,
                          out0, out1, out2, out3, out4, out5, out6, out7;
    for (i = 0; i < length; i+=8) {
        in0 = in[i];
        in1 = in[i+1];
        in2 = in[i+2];
        in3 = in[i+3];
        in4 = in[i+4];
        in5 = in[i+5];
        in6 = in[i+6];
        in7 = in[i+7];
        
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        in1s = spu_rlqwbyte(in1, rotate_bytes);
        in2s = spu_rlqwbyte(in2, rotate_bytes);
        in3s = spu_rlqwbyte(in3, rotate_bytes);
        in4s = spu_rlqwbyte(in4, rotate_bytes);
        in5s = spu_rlqwbyte(in5, rotate_bytes);
        in6s = spu_rlqwbyte(in6, rotate_bytes);
        in7s = spu_rlqwbyte(in7, rotate_bytes);
         
        out0 = spu_sel(in0, in0s, mask);
        out1 = spu_sel(in1, in1s, mask);
        out2 = spu_sel(in2, in2s, mask);
        out3 = spu_sel(in3, in3s, mask);
        out4 = spu_sel(in4, in4s, mask);
        out5 = spu_sel(in5, in5s, mask);
        out6 = spu_sel(in6, in6s, mask);
        out7 = spu_sel(in7, in7s, mask);
           
        out[i] = out0;
        out[i+1] = out1;
        out[i+2] = out2;
        out[i+3] = out3;
        out[i+4] = out4;
        out[i+5] = out5;
        out[i+6] = out6;
        out[i+7] = out7;
    }
}
#endif


int spu_main(unsigned long long dst, unsigned long long src, size_t size, char source_channel) {
    int i, n_vec_left, n_frames, rem_bytes, rotate_bytes;
    ushort8 mask;
    ushort8 in0, in0s, out0;

    unsigned int in_tags, out_tags;

    in_tags = MULTI_TAG_RESERVE(0, 2);
    out_tags = MULTI_TAG_RESERVE(2, 2);

#ifdef NO_SLICE	
    if (source_channel == 'r') {
        mask = (ushort8)spu_maskb(0x3333);
        rotate_bytes = -2;
    }
    else {
        mask = (ushort8)spu_maskb(0xCCCC);
        rotate_bytes = 2;
	}
#endif
       
    n_frames = size >> (BUF_SIZE_SHIFT+4);
    
    /* Read input buffer for the first loop iteration */
    mfc_get(in[0], src, sizeof(ushort8)<<BUF_SIZE_SHIFT, in_tags, 0, 0);
    src += sizeof(ushort8)<<BUF_SIZE_SHIFT;

#ifdef CORRECT	
    __CPROVER_assume( n_frames > 0 );
#else
	/* BUG: if n_frames is zero, the code will involve a double get to the same location */
#endif

    for (i = 0; i < n_frames - 1; i++) {

        TAG_ASSERT(in_tags, 0);
        TAG_ASSERT(out_tags, 2);

        /* Initiate read for the second buffer */
        mfc_get(in[(i+1)&1], src, sizeof(ushort8)<<BUF_SIZE_SHIFT, in_tags+((i+1)&1) , 0, 0);
        src += sizeof(ushort8)<<BUF_SIZE_SHIFT;
        
        /* Wait for the read */
        mfc_write_tag_mask(1 << (in_tags+(i&1)));
        mfc_read_tag_status_all();
        
        /* Wait for the write */
        mfc_write_tag_mask(1 << (out_tags+(i&1)));
        mfc_read_tag_status_all();
        
        /* Do the channel copy */
#ifdef NO_SLICE		
        channel_copy(in[i&1], out[i&1], BUF_SIZE, mask, rotate_bytes);
#endif
        
        /* Write out the vectors */
        mfc_put(out[i&1], dst, sizeof(ushort8)<<BUF_SIZE_SHIFT, out_tags+(i&1), 0, 0);
        dst += sizeof(ushort8)<<BUF_SIZE_SHIFT;
    }

    /* Calculate the last full frame */

    n_vec_left = (size >> 4) & BUF_SIZE_MASK;
    
    /* Initiate read for the partial buffer */
    mfc_get(in[n_frames&1], src, sizeof(ushort8)*n_vec_left, in_tags+(n_frames&1), 0, 0);
    src += sizeof(ushort8)*n_vec_left;
    
    /* Wait for the read */
    mfc_write_tag_mask(1 << (in_tags+((n_frames-1)&1)));
    mfc_read_tag_status_all();
    
    /* Wait for the write */
    mfc_write_tag_mask(1 << (out_tags+((n_frames-1)&1)));
    mfc_read_tag_status_all();
    
    /* Do the channel copy */
#ifdef NO_SLICE
    channel_copy(in[(n_frames-1)&1], out[(n_frames-1)&1], BUF_SIZE, mask, rotate_bytes);
#endif	
    
    /* Write out the vectors */
    mfc_put(out[(n_frames-1)&1], dst, sizeof(ushort8)<<BUF_SIZE_SHIFT, out_tags+((n_frames-1)&1), 0, 0);
    dst += sizeof(ushort8)<<BUF_SIZE_SHIFT;

    /* Calculate the partial frame */
    
    /* Wait for the read */
    mfc_write_tag_mask(1 << (in_tags+(n_frames&1)));
    mfc_read_tag_status_all();
    
    /* Wait for the write */
    mfc_write_tag_mask(1 << (out_tags+(n_frames&1)));
    mfc_read_tag_status_all();
    
    /* Do the channel copy */
#ifdef NO_SLICE	
    for (i = 0; i < n_vec_left; i++) {
        in0 = in[n_frames&1][i];
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        out0 = spu_sel(in0, in0s, mask);
        out[n_frames&1][i] = out0;
	}
#endif	
    
    /* Calculate the last chunk if the file size is not a multiple of 16 bytes */
    rem_bytes = size & 15;
    if (rem_bytes) {
#ifdef NO_SLLICE		
        in0 = in[n_frames&1][i];
        in0s = spu_rlqwbyte(in0, rotate_bytes);
        out0 = spu_sel(in0, in0s, mask);
        out[n_frames&1][i] = out0;
#endif
        n_vec_left++;
    }
    
    /* Write remaining vectors */
    mfc_put(out[n_frames&1], dst, sizeof(ushort8)*n_vec_left, out_tags+1, 0, 0);

    /* Wait */
    mfc_write_tag_mask(1 << (out_tags+1));
    mfc_read_tag_status_all();
}
