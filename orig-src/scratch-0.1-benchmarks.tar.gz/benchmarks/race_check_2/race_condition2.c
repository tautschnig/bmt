/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include <stdio.h>

char ls_buffer[65536] __attribute__ ((aligned(128)));

/* SPE program that demonstrates a common race condition
 */

int spu_main(unsigned long long speid __attribute__ ((unused)),
	 unsigned long long ea_buffer,
	 unsigned long long envp  __attribute__ ((unused)))
{
  char c;

  mfc_write_tag_mask(0xFFFFFFFF);

  /* Race Condition 2 - Incorrect use of fence. In this case, we are 
   * copying a 32K system memory buffer to another system memory buffer.
   * Since the transfer must be broken into two DMAs, the two transfers 
   * can not be ordered using a fence. Fencing the first PUT only ensures
   * that it can not be initiated before the GETs complete. However, the
   * following PUT can be. Instead, a barrier should have been used.
   */
  printf("RACE CONDITION 2\n");
  mfc_get(&ls_buffer[0], ea_buffer, 16384, 1, 0, 0);
  mfc_get(&ls_buffer[16384], ea_buffer+16384, 16384, 1, 0, 0);
#ifdef CORRECT
  mfc_putb
#else
  mfc_putf
#endif
    (&ls_buffer[0], ea_buffer+32768, 16384, 1, 0, 0);
  mfc_put(&ls_buffer[16384], ea_buffer+49152, 16384, 1, 0, 0);

  mfc_read_tag_status_all();

  return 0;
}
