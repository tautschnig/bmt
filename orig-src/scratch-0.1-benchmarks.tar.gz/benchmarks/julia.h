/* --------------------------------------------------------------  */
/* Copyright (c) 1984-2005, Keenan Crane                           */
/* All rights reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the following */
/* conditions are met:                                             */
/*                                                                 */
/* Redistributions of source code must retain the above copyright  */
/* notice, this list of conditions and the following disclaimer.   */
/* Redistributions in binary form must reproduce the above         */
/* copyright notice, this list of conditions and the following     */
/* disclaimer in the documentation and/or other materials provided */
/* with the distribution.                                          */
/*                                                                 */
/* The name of Keenan Crane may not be used to endorse or promote  */
/* products derived from this software without specific prior      */
/* written permission.                                             */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#define NUM_SPES	        16	
#define MAILBOX_DEPTH           4
#define MULTI_BUFFER            2

#define MAX_IMG_WIDTH           1024 
#define MAX_IMG_HEIGHT          1024

#define HUGE_PAGE_SIZE          (16 * 1024 * 1024)
#define HUGE_PAGE_SHIFT         24


#define EXIT_SPE_OP             1
#define FLUSH_SPE_OP            2
#define RENDER_CONTEXT_SPE_OP   3
#define RAY_REGION_SPE_OP       5

#define BUFFER_FREE             -1      /* Buffer Free for SPE to fill */
#define BUFFER_READY            0       /* Buffer Ready for PPE to process */

#define R_SHIFT         24
#define G_SHIFT         16
#define B_SHIFT         8
#define S_SHIFT         0

#define MAX_NUM_FRAMES		100
typedef struct
{
  float eyeP[4];		// eye location
  float lightP[4];		// light location
  float scolor[4];		// Stain Color for SPE
  float epsilonP;		// precision of ray tracing
  unsigned int shadowsP;	// flag for drawing shadows
  unsigned int textureP;	// flag for Texturing 
  unsigned int iterationsP;	// maximum number of iterations used to determine convergence
  unsigned int wb_addr;		// Write back to signal frame complete
  unsigned int tex_width;	// Cubemap width
  unsigned int tex_height;	// Cubemap height
  unsigned int img_width;	// image width 
  unsigned int img_height;	// image height 
  unsigned int fmbase[6];	// face map base EAs
  unsigned char pad[20];	// Pad to nearest cache line
}
rendering_context __attribute__ ((aligned (128)));

#define HAVOC_RENDERING_CONTEXT(c) \
  c.eyeP[0] = __CPROVER_ndet_float(); \
  c.eyeP[1] = __CPROVER_ndet_float(); \
  c.eyeP[2] = __CPROVER_ndet_float(); \
  c.eyeP[3] = __CPROVER_ndet_float(); \
  c.lightP[0] = __CPROVER_ndet_float(); \
  c.lightP[1] = __CPROVER_ndet_float(); \
  c.lightP[2] = __CPROVER_ndet_float(); \
  c.lightP[3] = __CPROVER_ndet_float(); \
  c.scolor[0] = __CPROVER_ndet_float(); \
  c.scolor[1] = __CPROVER_ndet_float(); \
  c.scolor[2] = __CPROVER_ndet_float(); \
  c.scolor[3] = __CPROVER_ndet_float(); \
  c.shadowsP = __CPROVER_ndet_int(); \
  c.textureP = __CPROVER_ndet_int(); \
  c.iterationsP = __CPROVER_ndet_int(); \
  c.wb_addr = __CPROVER_ndet_int(); \
  c.tex_width = __CPROVER_ndet_int(); \
  c.tex_height = __CPROVER_ndet_int(); \
  c.img_width = __CPROVER_ndet_int(); \
  c.img_height = __CPROVER_ndet_int(); \
  c.fmbase[0] = __CPROVER_ndet_int(); \
  c.fmbase[1] = __CPROVER_ndet_int(); \
  c.fmbase[2] = __CPROVER_ndet_int(); \
  c.fmbase[3] = __CPROVER_ndet_int(); \
  c.fmbase[4] = __CPROVER_ndet_int(); \
  c.fmbase[5] = __CPROVER_ndet_int();


typedef struct
{
  float dir_top_start[4];	// ray direction vector top left
  float dir_top_stop[4];	// ray direction vector top right
  float dir_bottom_start[4];	// ray direction vector bottom left
  float dir_bottom_stop[4];	// ray direction vector bottom right
  float muP[4];			// constant specifying the Julia set
  unsigned int fb_start;	// fb start address
  int column_start;		// start region at this column
  int column_count;		// render this many columns
  unsigned char pad[36];	// Pad to nearest cache line
}
rendering_region __attribute__ ((aligned (128)));

#define HAVOC_RENDERING_REGION(r) \
  r.dir_top_start[0] = __CPROVER_ndet_float(); \
  r.dir_top_start[1] = __CPROVER_ndet_float();	\
  r.dir_top_start[2] = __CPROVER_ndet_float();	\
  r.dir_top_start[3] = __CPROVER_ndet_float();	\
  r.dir_top_stop[0] = __CPROVER_ndet_float();	\
  r.dir_top_stop[1] = __CPROVER_ndet_float();	\
  r.dir_top_stop[2] = __CPROVER_ndet_float(); \
  r.dir_top_stop[3] = __CPROVER_ndet_float(); \
  r.dir_bottom_start[0] = __CPROVER_ndet_float();	\
  r.dir_bottom_start[1] = __CPROVER_ndet_float();	\
  r.dir_bottom_start[2] = __CPROVER_ndet_float();	\
  r.dir_bottom_start[3] = __CPROVER_ndet_float();	\
  r.dir_bottom_stop[0] = __CPROVER_ndet_float();	\
  r.dir_bottom_stop[1] = __CPROVER_ndet_float();	\
  r.dir_bottom_stop[2] = __CPROVER_ndet_float();	\
  r.dir_bottom_stop[3] = __CPROVER_ndet_float();\
  r.muP[0] = __CPROVER_ndet_float();		\
  r.muP[1] = __CPROVER_ndet_float();		\
  r.muP[2] = __CPROVER_ndet_float();		\
  r.muP[3] = __CPROVER_ndet_float();		\
  r.fb_start = __CPROVER_ndet_int(); \
  r.column_start = __CPROVER_ndet_int(); \
  r.column_count = __CPROVER_ndet_int();





  unsigned int fb_start;	// fb start address
  int column_start;		// start region at this column
  int column_count;		// render this many columns
  unsigned char pad[36];	// Pad to nearest cache line



typedef struct
{
  // Julia set parameters ----------
  //
  unsigned int maxIterations;	// maximum number of iterations used to determine convergence
  float epsilon;		// precision of ray tracing
  float curMu[4];		// current constant parameters (used for morphing)

  // camera parameters ----------
  //
  float fov;
  float aspect;
  int WindowSize[2];
  float translate[2];
  float zoom;
  float curRotation[16];

  // rendering parameters ----------
  //
  int shadows;			// whether self-shadowing is being rendered
  int textures;			// whether textures are being rendered
}
client_context __attribute__ ((aligned (128)));

struct vertex
{
  float x;
  float y;
  float z;
};


typedef struct
{
  float spe_w[NUM_SPES];
}
work_weights;


