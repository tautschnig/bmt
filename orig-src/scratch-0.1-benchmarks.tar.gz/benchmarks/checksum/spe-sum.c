/* --------------------------------------------------------------  */
/* (C)Copyright 2005,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * spe-sum.c
 *
 * Stand-alone 'spulet' that computes a checksum for file.
 * The file contents are mmap'd into the effective address
 * space and DMAs are used to stage data into LS.
 * 
 * The purpose here is to illustrate how an SPE-based
 * file filter might be constructed.  For example, an
 * SPE could be used to authenticate or decompress data,
 * rather than compute a simple checksum.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <spu_mfcio.h>

#define NR_BUFS         4
#define BUF_SIZE_SHIFT	12
#define BUF_SIZE        (1 << BUF_SIZE_SHIFT)
#define BUF_SIZE_MASK	(BUF_SIZE - 1)

#define likely(_c)     \
    __builtin_expect((_c), 1)
#define unlikely(_c)    \
    __builtin_expect((_c), 0)

#define min(_a, _b)	((_a < _b) ? _a : _b)

typedef
#ifdef NO_SLICE
union {
    unsigned long long all64;
    unsigned int by32[2];
}
#else
unsigned int
#endif
addr64;

/* Intermediate buffer */
static char buf[BUF_SIZE * NR_BUFS] __attribute__ ((aligned(128)));

int sum = 0;
size_t total_bytes = 0;

static void do_checksum(char *buf, int nbytes)
{
    for (; nbytes > 0; nbytes--, total_bytes++, buf++) {
		sum = (sum >> 1) + ((sum & 1) << 15);
		sum += *buf;
		sum &= 0xffff;
    }
}



/* Calculate a rotated checksum, using blocksize=1024. */
int spu_main (unsigned long long src, size_t outer_size)
{
      unsigned int nbufs = outer_size >> BUF_SIZE_SHIFT;

      unsigned int i = 0;
      unsigned int size = BUF_SIZE;
      unsigned int nbufs_to_xfer = nbufs;
      addr64 _src;
      
      _src = src;

      /* Kick off DMAs to get multi-buffer scheme rolling... */
      assert(NR_BUFS==4);
      if(nbufs > 0) {
        mfc_get(&buf[0 * BUF_SIZE], _src, size, 0, 0, 0);
        _src += BUF_SIZE;
        nbufs_to_xfer--;
	  }
      if(nbufs > 1) {
        mfc_get(&buf[1 * BUF_SIZE], _src, size, 1, 0, 0);
        _src += BUF_SIZE;
        nbufs_to_xfer--;
      }
      if(nbufs > 2) {
        mfc_get(&buf[2 * BUF_SIZE], _src, size, 2, 0, 0);
        _src += BUF_SIZE;
        nbufs_to_xfer--;
	  }
      if(nbufs > 3) {
        mfc_get(&buf[3 * BUF_SIZE], _src, size, 3, 0, 0);
        _src += BUF_SIZE;
        nbufs_to_xfer--;
      }
      
      i = 0;

      while (nbufs > 0) {
        unsigned int mask = (1 << i);
	
        mfc_write_tag_mask(mask);
        mfc_read_tag_status_all();

        assert((i*BUF_SIZE >= 0) && (i*BUF_SIZE < BUF_SIZE * NR_BUFS));
	
#ifdef NO_SLICE
        do_checksum(&buf[i * BUF_SIZE], BUF_SIZE);
#endif
        if (likely(nbufs_to_xfer > 0)) {
            mfc_get(&buf[
#ifdef CORRECT
			i * 
#else
            /* BUG - multiplication by 'i' is missing, will result in same buffer being used repeatedly */
#endif
                  BUF_SIZE], _src, size, i, 0, 0);
            _src += BUF_SIZE;
            nbufs_to_xfer--;
	    }
        i = (i >= NR_BUFS-1) ? 0 : i+1;
        nbufs--;
      }

      src += (nbufs * BUF_SIZE);

      printf("%05d %5lu\n", sum, (total_bytes+1023) >> 10);
}
