#include "spu_mfcio.h"

#include <stdbool.h>

bool reserved[32]; // Guaranteed to be initialised to false by C standard


extern unsigned int __mfc_multi_tag_reserve (unsigned int num_tags)
{
	int result;
	assert(num_tags == 2); // For now we make this restriction.
	
	assert(
		    (!reserved[0] && !reserved[1]) ||		    
			(!reserved[1] && !reserved[2]) ||
		    (!reserved[2] && !reserved[3]) ||
		    (!reserved[3] && !reserved[4]) ||
		    (!reserved[4] && !reserved[5]) ||
		    (!reserved[5] && !reserved[6]) ||
		    (!reserved[6] && !reserved[7]) ||
		    (!reserved[7] && !reserved[8]) ||
		    (!reserved[8] && !reserved[9]) ||
		    (!reserved[9] && !reserved[10]) ||
		    (!reserved[10] && !reserved[11]) ||
		    (!reserved[11] && !reserved[12]) ||
		    (!reserved[12] && !reserved[13]) ||
		    (!reserved[13] && !reserved[14]) ||
		    (!reserved[14] && !reserved[15]) ||
		    (!reserved[15] && !reserved[16]) ||
		    (!reserved[16] && !reserved[17]) ||
		    (!reserved[17] && !reserved[18]) ||
		    (!reserved[18] && !reserved[19]) ||
		    (!reserved[19] && !reserved[20]) ||
		    (!reserved[20] && !reserved[21]) ||
		    (!reserved[21] && !reserved[22]) ||
		    (!reserved[22] && !reserved[23]) ||
		    (!reserved[23] && !reserved[24]) ||
		    (!reserved[24] && !reserved[25]) ||
		    (!reserved[25] && !reserved[26]) ||
		    (!reserved[26] && !reserved[27]) ||
		    (!reserved[27] && !reserved[28]) ||
		    (!reserved[28] && !reserved[29]) ||
		    (!reserved[29] && !reserved[30]) ||
		    (!reserved[30] && !reserved[31])
		   );
	
	result = __CPROVER_ndet_int();
	__CPROVER_assume(result >= 0 && result < 31 && !reserved[result] && !reserved[result+1]);
	reserved[result] = 1;
	reserved[result+1] = 1;
	return result;
	
}

extern unsigned int __mfc_tag_reserve (void)
{
  if(	     reserved[0] && 
	     reserved[1] && 
	     reserved[2] && 
	     reserved[3] && 
	     reserved[4] && 
	     reserved[5] && 
	     reserved[6] && 
	     reserved[7] && 
	     reserved[8] && 
	     reserved[9] && 
	     reserved[10] && 
	     reserved[11] && 
	     reserved[12] && 
	     reserved[13] && 
	     reserved[14] && 
	     reserved[15] && 
	     reserved[16] && 
	     reserved[17] && 
	     reserved[18] && 
	     reserved[19] && 
	     reserved[20] && 
	     reserved[21] && 
	     reserved[22] && 
	     reserved[23] && 
	     reserved[24] && 
	     reserved[25] && 
	     reserved[26] && 
	     reserved[27] && 
	     reserved[28] && 
	     reserved[29] && 
	     reserved[30] && 
	     reserved[31] )
    {
      assert(false);
      return MFC_TAG_INVALID;
    }

  int result;
  result = __CPROVER_ndet_int();
  __CPROVER_assume(result >= 0 && result < 32 && !reserved[result]);
  reserved[result] = 1;
  return result;
}

