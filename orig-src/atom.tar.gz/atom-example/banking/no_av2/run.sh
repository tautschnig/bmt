INST="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/instrument-cmk"
COMP="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/compile-cmk"

INSPECTCC="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/inspect-cc"

echo "*-----------------------------*"
echo $INST ./banking.c
$INST ./banking_no_av2.c
echo "*-----------------------------*"
echo $COMP ./banking.instr.c
$COMP ./banking_no_av2.instr.c

~/bin/inspect --maxruns 1 --csv atom ./target out 2 >run_2_test.txt
~/bin/inspect --maxruns 1 --csv atom ./target out 8 >run_8_test.txt
#~/bin/inspect --maxruns 1 --csv atom ./target out 4 >run_4.txt
#~/bin/inspect --maxruns 1 --csv atom ./target out 5 >run_5.txt
 
#echo $INSPECTCC ./banking.c
#$INSPECTCC ./banking.c
