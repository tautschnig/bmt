#grep "\(NOTICE: #.threads\|printPIEdgeStats\|Atomicity checker: checking\|violation_is_possible:count_simplified_away\|Atomicity checker (chao/one-at-a-time):\)" atom00*/run*.txt banking/*/run_*.txt
#ls -lh atom00*/run*.txt banking/*/run_*.txt

grep "\(violation_is_possible: count_simplified_away\)" atom00*/run*.txt banking/*/run_*.txt