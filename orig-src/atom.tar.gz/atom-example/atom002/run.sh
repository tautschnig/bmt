INST="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/instrument-cmk"
COMP="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/compile-cmk"

INSPECTCC="/home/chaowang/HOME/src/ACME/inspect-cmk/bin/inspect-cc"

echo "*-----------------------------*"
echo $INST ./banking.c
$INST ./atom002.c
echo "*-----------------------------*"
echo $COMP ./banking.instr.c
$COMP ./atom002.instr.c

~/bin/inspect --maxruns 1 --csv atom ./target 
#echo $INSPECTCC ./banking.c
#$INSPECTCC ./banking.c
