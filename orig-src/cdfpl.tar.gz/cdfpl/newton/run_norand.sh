#!

filename=$1_$2.result_norand

if [ -e $filename ] 
then
echo Skipping existing file: ${filename}
else
timeout 3600 /usr/bin/time -o $filename --append ai --inline --filter-dec-vars IN --proof-search newton.c -DNR=$2 -DITERATIONS=$1 > $filename
fi

