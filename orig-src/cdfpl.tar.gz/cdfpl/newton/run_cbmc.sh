#!

filename=$1_$2.result_cbmc

if [ -e ${filename} ]
then
  echo Skipping ${filename}
else
timeout 3600 /usr/bin/time -o $filename --append cbmc newton.c -DNR=$2 -DITERATIONS=$1 > $filename
fi
