#!

for j in `seq 3`
do
  for i in `seq 8`
  do
    ./run.sh $j $i
    ./run_nolearning.sh $j $i
    ./run_norand.sh $j $i
    ./run_cbmc.sh $j $i
  done
done  
