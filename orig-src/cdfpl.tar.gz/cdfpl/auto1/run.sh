#!
SUFFIX=result

if [ -e $1_$2.${SUFFIX} ]
then
  echo Skipping existing file $1_$2.${SUFFIX}
else
timeout 3600 /usr/bin/time -o $1_$2.${SUFFIX} --append ai --unsound-nan --inline --preprocess-const-prop --max-array-size 100 --proof-search --filter-dec-vars IN *.c --dec-heur-rand --set-var-range IN1,0.0,80.,IN2,0.7,1,IN3,12,16,IN4,0.0,84 -DLOC=$1 -DNR=$2 > $1_$2.${SUFFIX}
fi
