#!

for loc in `seq 4`
do
  for nr in `seq 8`
  do
    ./run.sh ${loc} ${nr}
    ./run_nolearning.sh ${loc} ${nr}
  done
done 
