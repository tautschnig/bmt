#!

SUFFIX=result_cbmc

if [ -e $1_$2.${SUFFIX} ]
then
  echo Skipping existing file $1_$2.${SUFFIX}
else
timeout 3600 /usr/bin/time -o $1_$2.${SUFFIX} cbmc -DCBMC --slice-formula --unwind 100 *.c -DLOC=$1 -DNR=$2 > $1_$2.${SUFFIX}
fi
