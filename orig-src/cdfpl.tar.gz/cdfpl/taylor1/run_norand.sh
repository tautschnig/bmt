#!
SUFFIX=result_norand

FILENAME=$1.${SUFFIX}

if [ -e $FILENAME ]
then 
  echo Skipping existing file ${FILENAME}
else
timeout 3600 /usr/bin/time -o ${FILENAME} --append ai --proof-search sine.c -DNR=$1 > ${FILENAME}
fi
