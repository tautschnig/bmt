#!

for FILENAME in $@
do
VAL=`grep user ${FILENAME}`
if [ -z "$VAL" ] 
then
  echo 3600 / 
else
  VAL=`echo $VAL | sed -e "s/\(.*\)user.*/\1/"`
  grep -q -i "verification successful" $FILENAME
  RESULT=$?
  echo $VAL $RESULT
fi 
done
