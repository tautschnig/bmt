#!

SUFFIX=result

if [ -e $1_$2.${SUFFIX} ] 
then 
  echo Skipping existing file $1_$2.${SUFFIX}
else

if [ $# -lt 2 ]
then
  echo "Please specify number of iterations and number of bound"
  exit 1;
fi

rm -f $1_$2.${SUFFIX}

timeout 3600 /usr/bin/time -o $1_$2.${SUFFIX} --append ai --set-var-range IN1_1,-1000,65534.0,IN2_1,-1000,65534.0,IN3_1,-1000,65534.0 --inline --proof-search --dec-heur-rand -DITERATIONS=$1 -DNR=$2 --preprocess-const-prop --filter-dec-vars IN *.c > $1_$2.${SUFFIX}
fi
