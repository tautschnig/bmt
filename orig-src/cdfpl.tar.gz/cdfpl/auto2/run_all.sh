#!

for nr in 1 2
do
  for it in `seq 10`
  do
    ./run.sh ${it} ${nr}
    ./run_nolearning.sh ${it} ${nr}
    ./run_norand.sh ${it} ${nr}
    ./run_cbmc.sh ${it} ${nr}
  done
done
