#!

SUFFIX=result_cbmc

if [ $# -lt 2 ]
then
  echo "Please specify number of iterations and number of bound"
  exit 1;
fi

if [ -e $1_$2.${SUFFIX} ]
then
  echo Skipping existing file $SUFFIX
else
timeout 3600 /usr/bin/time -o $1_$2.${SUFFIX} --append cbmc -DITERATIONS=$1 -DNR=$2 *.c > $1_$2.${SUFFIX}
fi
