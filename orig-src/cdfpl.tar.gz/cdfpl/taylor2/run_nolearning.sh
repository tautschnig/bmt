#!
SUFFIX=result_nolearning

FILENAME=$1.${SUFFIX}

if [ -e $FILENAME ]
then 
  echo Skipping existing file ${FILENAME}
else
timeout 3600 /usr/bin/time -o ${FILENAME} --append ai --disable-learning --dec-heur-rand --proof-search square.c -DNR=$1 > ${FILENAME}
fi
