#!
SUFFIX=result_cbmc

FILENAME=$1.${SUFFIX}

if [ -e $FILENAME ]
then 
  echo Skipping existing file ${FILENAME}
else
timeout 3600 /usr/bin/time -o ${FILENAME} --append cbmc -DNR=$1 square.c > ${FILENAME}
fi
