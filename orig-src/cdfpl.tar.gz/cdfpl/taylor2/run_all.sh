#!
for i in `seq 8`
do
  ./run.sh $i 
  ./run_nolearning.sh $i
  ./run_norand.sh $i
  ./run_cbmc.sh $i
done

